#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "def.h"
#include "_fat12.h"



int main(int argc, char *argv[])
{	
	char *pFileName1 = "hello.c";
	char *pFileName2 = "hello.exe";
	char *pFileName3 = "hello";
	
    if(argc != 2)
    {
        fprintf(stderr, "usage: TestFindFile Image\n");
        exit(EXIT_FAILURE);
    }
	
	InitFat12FileSystem(argv[1]);
	
	if(FindFileInRootDir(pFileName1) != 0xFFFF)
	{
		printf("Find the file: %s\n", pFileName1);
	}
	else
	{
		printf("Can't find the file: %s\n", pFileName1);
	}
	
	if(FindFileInRootDir(pFileName2) != 0xFFFF)
	{
		printf("Find the file: %s\n", pFileName2);
	}
	else
	{
		printf("Can't find the file: %s\n", pFileName2);
	}

	if(FindFileInRootDir(pFileName3) != 0xFFFF)
	{
		printf("Find the file: %s\n", pFileName3);
	}
	else
	{
		printf("Can't find the file: %s\n", pFileName3);
	}
	
	FreeFat12FileSystem();
	return 0;
}