#ifndef __FAT12_H__
#define __FAT12_H__


#include "def.h"

/********************************************************************

                    FAT12 FileSystem Image
    
********************************************************************/
// 
// �Ӿ�����ɾ���ļ�
UINT16 DeleteFileFromImage(const PCHAR FileName);
//
// �Ӿ������ļ�
UINT16 CopyFileFromImage(const PCHAR PathName);
//
// �����ļ�������
UINT16 AddFile2Image(const PCHAR PathName);
//
// �Ӿ����ȡ�ļ�
UINT16 CopyFileBase(FILE *NewFp, const PCHAR FileName);
//
// �����ļ�������
UINT16 AddFileBase(FILE *NewFp, const PCHAR DosFileName);

/********************************************************************

                    FAT12 FileSystem Initialization
    
********************************************************************/
void InitFat12FileSystem(const PUCHAR ImageFileName);
void FreeFat12FileSystem(void);

/********************************************************************

                       FAT12 FileSystem API
    
********************************************************************/
//
// ɾ���ļ�
VOID DeleteFile(const UINT16 iRootDirEntry);
//
// ��ȡʣ����̿ռ�
UINT16 GetRestSector(VOID);



#endif