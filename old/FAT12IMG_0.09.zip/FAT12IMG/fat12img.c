#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fat12.h"


void PrintUsage(const char *str1);



int main(int argc, char *argv[])
{
	if((argc == 1) || ((argc == 2) && (!stricmp(argv[1], "-h"))))
	{
		PrintUsage(argv[0]);
		return 0;
	}
	
    if(argc == 4 && (!stricmp(argv[1], "-a")))
    {
		InitFat12FileSystem(argv[2]);

		AddFile2Image(argv[3]);
		
		FreeFat12FileSystem();
    }

	return 0;
}

void PrintUsage(const char *str1)
{
	printf("(C) Mumu3w@outlook.com  %s\n\n", __DATE__);
	printf("Usage: %s <-a | -h> Image [File]\n", str1);
	printf("  -a Add file to image\n");
	printf("  -h Show this usage\n");
}