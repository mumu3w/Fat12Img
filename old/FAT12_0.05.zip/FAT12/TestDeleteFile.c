#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "def.h"
#include "_fat12.h"



int main(int argc, char *argv[])
{	
	char *pFileName1 = "hello.c";
	char *pFileName2 = "TEST.TXT";
	char *pFileName3 = "hello1.c";
	char *pFileName4 = "hello11.c";
	unsigned int iRootDirEntry;
	
    if(argc != 2)
    {
        fprintf(stderr, "usage: TestFindFile Image\n");
        exit(EXIT_FAILURE);
    }
	
	InitFat12FileSystem(argv[1]);
	
	iRootDirEntry = FindFileInRootDir(pFileName1);
	if(iRootDirEntry != 0xFFFF)
	{
		printf("Find the file: %12s", pFileName1);
		printf("  iRootDirEntry: 0x%X\n", iRootDirEntry);
		DeleteFile(iRootDirEntry);
	}

	iRootDirEntry = FindFileInRootDir(pFileName2);
	if(iRootDirEntry != 0xFFFF)
	{
		printf("Find the file: %12s", pFileName2);
		printf("  iRootDirEntry: 0x%X\n", iRootDirEntry);
		DeleteFile(iRootDirEntry);
	}

	iRootDirEntry = FindFileInRootDir(pFileName3);
	if(iRootDirEntry != 0xFFFF)
	{
		printf("Find the file: %12s", pFileName3);
		printf("  iRootDirEntry: 0x%X\n", iRootDirEntry);
		DeleteFile(iRootDirEntry);
	}

	iRootDirEntry = FindFileInRootDir(pFileName4);
	if(iRootDirEntry != 0xFFFF)
	{
		printf("Find the file: %12s", pFileName4);
		printf("  iRootDirEntry: 0x%X\n", iRootDirEntry);
		DeleteFile(iRootDirEntry);
	}
	
	FreeFat12FileSystem();
	return 0;
}

/*
FileName: TEST.TXT
FileSize: 24686 bytes
FirstCluster: 0x3
ClusterNumber: 0x3
ClusterNumber: 0x4
ClusterNumber: 0x6
ClusterNumber: 0x8
ClusterNumber: 0x15
ClusterNumber: 0x16
ClusterNumber: 0x17
ClusterNumber: 0x18
ClusterNumber: 0x19
ClusterNumber: 0x1A
ClusterNumber: 0x1B
ClusterNumber: 0x1C
ClusterNumber: 0x1D
ClusterNumber: 0x1E
ClusterNumber: 0x1F
ClusterNumber: 0x20
ClusterNumber: 0x21
ClusterNumber: 0x22
ClusterNumber: 0x23
ClusterNumber: 0x24
ClusterNumber: 0x25
ClusterNumber: 0x26
ClusterNumber: 0x27
ClusterNumber: 0x28
ClusterNumber: 0x29
ClusterNumber: 0x2A
ClusterNumber: 0x2B
ClusterNumber: 0x2C
ClusterNumber: 0x2D
ClusterNumber: 0x2E
ClusterNumber: 0x2F
ClusterNumber: 0x30
ClusterNumber: 0x31
ClusterNumber: 0x32
ClusterNumber: 0x33
ClusterNumber: 0x34
ClusterNumber: 0x35
ClusterNumber: 0x36
ClusterNumber: 0x37
ClusterNumber: 0x38
ClusterNumber: 0x39
ClusterNumber: 0x3A
ClusterNumber: 0x3B
ClusterNumber: 0x3C
ClusterNumber: 0x3D
ClusterNumber: 0x3E
ClusterNumber: 0x3F
ClusterNumber: 0x40
ClusterNumber: 0x41
*/