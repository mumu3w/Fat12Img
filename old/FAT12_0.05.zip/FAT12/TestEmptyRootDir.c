#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "def.h"
#include "_fat12.h"



int main(int argc, char *argv[])
{	
    if(argc != 2)
    {
        fprintf(stderr, "usage: TestEmptyRootDir Image\n");
        exit(EXIT_FAILURE);
    }
	
	InitFat12FileSystem(argv[1]);
	
	printf("Empty root dir entry: 0x%X\n", FindEmptyRootDirEntry());
	printf("Empty fat entry: 0x%X\n", FindEmptyFatEntry(2));
	
	FreeFat12FileSystem();
	return 0;
}