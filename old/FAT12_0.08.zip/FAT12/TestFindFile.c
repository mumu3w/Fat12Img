#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "def.h"
#include "_fat12.h"



int main(int argc, char *argv[])
{	
	char *pFileName1 = "hello.c";
	char *pFileName2 = "hello.exe";
	char *pFileName3 = "hello";
	char *pFileName4 = "hello13.c";
	unsigned int Value;
	
    if(argc != 2)
    {
        fprintf(stderr, "usage: TestFindFile Image\n");
        exit(EXIT_FAILURE);
    }
	
	InitFat12FileSystem(argv[1]);
	
	Value = FindFileInRootDir(pFileName1);
	if(Value != 0xFFFF)
	{
		printf("Find the file: %s", pFileName1);
		printf("            iRootDirEntry: 0x%X\n", Value);
	}
	else
	{
		printf("Can't find the file: %s\n", pFileName1);
	}
	
	Value = FindFileInRootDir(pFileName2);
	if(Value != 0xFFFF)
	{
		printf("Find the file: %s\n", pFileName2);
		printf("iRootDirEntry: 0x%X\n", Value);
	}
	else
	{
		printf("Can't find the file: %s\n", pFileName2);
	}
	
	Value = FindFileInRootDir(pFileName3);
	if(Value != 0xFFFF)
	{
		printf("Find the file: %s\n", pFileName3);
		printf("iRootDirEntry: 0x%X\n", Value);
	}
	else
	{
		printf("Can't find the file: %s\n", pFileName3);
	}
	
	Value = FindFileInRootDir(pFileName4);
	if(Value != 0xFFFF)
	{
		printf("Find the file: %s", pFileName4);
		printf("            iRootDirEntry: 0x%X\n", Value);
	}
	else
	{
		printf("Can't find the file: %s\n", pFileName4);
	}
	
	FreeFat12FileSystem();
	return 0;
}