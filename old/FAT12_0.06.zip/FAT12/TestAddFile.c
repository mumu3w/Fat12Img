#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "def.h"
#include "_fat12.h"



int main(int argc, char *argv[])
{
	FILE *NewFp;
	char *DosFileName = "HELLO   EXE";
	
    if(argc != 3)
    {
        fprintf(stderr, "usage: TestAddFile Image add_file\n");
        exit(EXIT_FAILURE);
    }
	
	InitFat12FileSystem(argv[1]);
	
    if(NULL == (NewFp = fopen(argv[2], "rb+")))
    {
        fprintf(stderr, "%s Can't open\n", argv[2]);
        exit(EXIT_FAILURE);
    }
	
	AddFileBase(NewFp, DosFileName);
	
	FreeFat12FileSystem();
	return 0;
}