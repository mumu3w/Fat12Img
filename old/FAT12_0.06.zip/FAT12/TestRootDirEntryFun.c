#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "def.h"
#include "_fat12.h"



int main(int argc, char *argv[])
{
	DIRENT DirEnt;
	
    if(argc != 2)
    {
        fprintf(stderr, "usage: TestRootDirEntryFun Image\n");
        exit(EXIT_FAILURE);
    }
	
	InitFat12FileSystem(argv[1]);
	
	printf("iRootDirEntry: 0x%X\n", ReadRootDirEntryValue(0, &DirEnt));
	WriteRootDirEntryValue(2, &DirEnt);
	WriteRootDirEntryValue(1, &DirEnt);
	
	FreeFat12FileSystem();
	return 0;
}