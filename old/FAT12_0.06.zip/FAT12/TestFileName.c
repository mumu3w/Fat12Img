#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "def.h"
#include "_fat12.h"



int main(void)
{
	char *pDosFileName1 = "HELLO   C  ";
	char DosFileName1[13];
	char *pDosFileName2 = "HELLO   EXE";
	char DosFileName2[13];
	char *pFileName1 = "hello.c";
	char FileName1[12];
	char *pFileName2 = "hello";
	char FileName2[12];
	
	printf("|123456789abcdef|\n");
	DosFileName2FileName(pDosFileName1, DosFileName1);
	printf("|%s|\n", pDosFileName1);
	printf("|%s|\n", DosFileName1);
	DosFileName2FileName(pDosFileName2, DosFileName2);
	printf("|%s|\n", pDosFileName2);
	printf("|%s|\n", DosFileName2);
	
	FileName2DosFileName(pFileName1, FileName1);
	printf("|%s|\n", pFileName1);
	printf("|%s|\n", FileName1);
	FileName2DosFileName(pFileName2, FileName2);
	printf("|%s|\n", pFileName2);
	printf("|%s|\n", FileName2);
	
	return 0;
}