#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "def.h"
#include "_fat12.h"

void PrintBlock(PUCHAR BlockBuf);

int main(int argc, char *argv[])
{
	char BlockBuf[SECTOR_SIZE];
	
    if(argc != 2)
    {
        fprintf(stderr, "usage: TestReadBlock Image\n");
        exit(EXIT_FAILURE);
    }
	
	InitFat12FileSystem(argv[1]);
	
	ReadBlock(0, BlockBuf);
	PrintBlock(BlockBuf);
	ReadBlock(1, BlockBuf);
	PrintBlock(BlockBuf);
	
	FreeFat12FileSystem();
	return 0;
}

void PrintBlock(PUCHAR BlockBuf)
{
	int i;
	
	for(i = 0; i < SECTOR_SIZE; i++)
    {   
        if(isprint(BlockBuf[i]))
        {
            printf("%c", BlockBuf[i]);
        }
        else
        {
            printf(".");
        }
        
        if((i+1) % 16 == 0)
        {
            printf("\n");
        }
    }
	printf("\n\n");
}