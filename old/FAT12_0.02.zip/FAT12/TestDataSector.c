#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "def.h"
#include "_fat12.h"



int main(int argc, char *argv[])
{
	char Buffer[512];
	
    if(argc != 2)
    {
        fprintf(stderr, "usage: TestDataSector Image\n");
        exit(EXIT_FAILURE);
    }
	
	InitFat12FileSystem(argv[1]);
	
	ReadDataSector(2, Buffer);
	WriteDataSector(2848, Buffer);
	
	FreeFat12FileSystem();
	return 0;
}