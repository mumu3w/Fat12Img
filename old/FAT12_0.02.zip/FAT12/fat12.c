#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "def.h"
#include "_fat12.h"


FILE *ImgFp;
UCHAR FAT1Buf[FAT1_SECROT_NUM * SECTOR_SIZE];
UCHAR FAT2Buf[FAT2_SECROT_NUM * SECTOR_SIZE];
UCHAR ROOTDirBuf[ROOT_DIR_SECTOR_NUM * SECTOR_SIZE];

/********************************************************************

                    FAT12 FileSystem ��ʼ��
    
********************************************************************/
//
// ��ʼ���ļ�ϵͳ
VOID InitFat12FileSystem(const PUCHAR ImageFileName)
{
    // �򿪴��̾����ļ�
    if(NULL == (ImgFp = fopen(ImageFileName, "rb+")))
    {
        fprintf(stderr, "%s Can't open\n", ImageFileName);
        exit(EXIT_FAILURE);
    }
    
    LoadFatEntryBuf();
    LoadRootDirEntryBuf();
}
//
// �ͷ��ļ�ϵͳ
VOID FreeFat12FileSystem(VOID)
{
    UpdateRootDirEntryBuf();
    UpdateFatEntry();
    fclose(ImgFp);
}

//
// ����FAT��������
VOID LoadFatEntryBuf(VOID)
{
    int i;
    
    for(i = 0; i < FAT1_SECROT_NUM; i++)
    {
        ReadBlock(FAT1_START_SECTOR + i, &FAT1Buf[i * SECTOR_SIZE]);
    }
    for(i = 0; i < FAT2_SECROT_NUM; i++)
    {
        ReadBlock(FAT2_START_SECTOR + i, &FAT2Buf[i * SECTOR_SIZE]);
    }
}

//
// ��FAT��д�ص��ļ�
VOID UpdateFatEntry(VOID)
{
    int i;
    
    for(i = 0; i < FAT1_SECROT_NUM; i++)
    {
        WriteBlock(FAT1_START_SECTOR + i, &FAT1Buf[i * SECTOR_SIZE]);
    }
    for(i = 0; i < FAT2_SECROT_NUM; i++)
    {
        WriteBlock(FAT2_START_SECTOR + i, &FAT2Buf[i * SECTOR_SIZE]);
    }
}

//
// ����RootDir��������
VOID LoadRootDirEntryBuf(VOID)
{
    int i;
    
    for(i = 0; i < ROOT_DIR_SECTOR_NUM; i++)
    {
        ReadBlock(ROOT_DIR_START_SECTOR + i, &ROOTDirBuf[i * SECTOR_SIZE]);
    }
}

//
// ��RootDir��д�ص��ļ�
VOID UpdateRootDirEntryBuf(VOID)
{
    int i;
    
    for(i = 0; i < ROOT_DIR_SECTOR_NUM; i++)
    {
        WriteBlock(ROOT_DIR_START_SECTOR + i, &ROOTDirBuf[i * SECTOR_SIZE]);
    }
}

/********************************************************************

                       FAT12 FileSystem API
    
********************************************************************/
//
// ��ȡʣ����̿ռ�
UINT16 GetRestSector(VOID)
{
	UINT16 iCurFatEntry = FIRSTENTRY, RestSectors = 0;
	
	for(/*empty*/; iCurFatEntry < DATA_SECTOR_NUM + FIRSTENTRY; 
					iCurFatEntry++)
	{
		if(ReadFatEntryValue(iCurFatEntry) == 0)
		{
			RestSectors++;
		}
	}
	
	return RestSectors;
}

//
// ���ļ�����8+3��ͨ�ļ���
VOID DosFileName2FileName(const PCHAR DosFileName, PCHAR FileName)
{
	int i;
	int fNameEnd = FILE_NAME_LEN - 1; // 7
	int fExtEnd = FILE_NAME_STR_LEN - 1; // 10
	
	// Name
	while(DosFileName[fNameEnd] == SPACE) // ȥ���ļ����ͺ�׺֮����ܵĿո�
	{
		fNameEnd--;
	}
	for(i = 0; i <= fNameEnd; i++)
	{
		FileName[i] = DosFileName[i];
	}
	
	// Ext
	while(DosFileName[fExtEnd] == SPACE)
	{
		fExtEnd--;
	}
	if(fExtEnd >= FILE_NAME_LEN) // ��׺ռ��8 9 10
	{
		FileName[++fNameEnd] = '.';
		for(i = FILE_NAME_LEN; i <= fExtEnd; i++)
		{
			FileName[++fNameEnd] = DosFileName[i];
		}
	}
	
	FileName[++fNameEnd] = NUL;
	// �ַ���תСд
	for(i = 0; i < fNameEnd; i++)
	{
		FileName[i] = tolower(FileName[i]);
	}
}

//
// ����ͨ�ļ���תΪ8+3��ʽ
VOID FileName2DosFileName(const PCHAR FileName, PCHAR DosFileName)
{
    int i, iExt, FileNameLen;
    PCHAR pExt;
    // ȡ���һ��'.'��λ��
    pExt = strrchr(FileName, '.');
    // �Ҳ���'.'��ʾû�к�׺��
    if(NULL == pExt)
    {
        for(i = 0; i < FILE_NAME_LEN; i++)
        {
            if(FileName[i] == NUL)
            {
                break;
            }
            DosFileName[i] = FileName[i];
        }
        // ���
        for(/*enpty*/; i < FILE_NAME_STR_LEN; i++)
        {
            DosFileName[i] = SPACE;
        }
    }
    else
    {
        // �ļ����ַ�����
        FileNameLen = pExt - FileName;
        for(i = 0; i < FileNameLen && i < FILE_NAME_LEN; i++)
        {
            DosFileName[i] = FileName[i];
        }
        // ���
        for(/*enpty*/; i < FILE_NAME_STR_LEN; i++)
        {
            DosFileName[i] = SPACE;
        }
		
		iExt = ++FileNameLen;
		// ��׺
		for(i = FILE_NAME_LEN; i < FILE_NAME_STR_LEN; 
								i++, iExt++)
		{
			if(FileName[iExt] == NUL)
			{
				break;
			}
			DosFileName[i] = FileName[iExt];
		}
		// ���
		for(/*enpty*/; i < FILE_NAME_STR_LEN; i++)
        {
            DosFileName[i] = SPACE;
        }
		
		// �ַ���ת��д
		for(i = 0; i < FILE_NAME_STR_LEN; i++)
		{
			DosFileName[i] = toupper(DosFileName[i]);
		}
    }
	
	DosFileName[FILE_NAME_STR_LEN + 1] = NUL;
}

//
// ��ȡһ��iRootDirEntry��ֵ
UINT16 ReadRootDirEntryValue(const UINT16 iRootDirEntry, PDIRENT pDirEnt)
{
    if(iRootDirEntry < ROOT_DIR_ENTRY_NUM)
    {
        *pDirEnt = *((PDIRENT)
                    &ROOTDirBuf[iRootDirEntry * ROOT_DIR_ENTRY_BIT]);
        return 0;
    }
    else
    {
        return (UINT16)-1;
    }
}

//
// ��iRootDirEntryд��ֵ
UINT16 WriteRootDirEntryValue(const UINT16 iRootDirEntry, 
                              const PDIRENT pDirEnt)
{
    if(iRootDirEntry < ROOT_DIR_ENTRY_NUM)
    {
        *((PDIRENT)&ROOTDirBuf[iRootDirEntry * ROOT_DIR_ENTRY_BIT])
        = *pDirEnt;
        
        return 0;
    }
    else
    {
        return (UINT16)-1;
    }
}

//
// ��ȡ��ǰiFatEntry��ֵ
UINT16 ReadFatEntryValue(const UINT16 iFatEntry)
{
    UINT16 ValueTmp, FatEntryByteOff;
    
    // iFatEntry��FATBuf�е�ƫ��(ÿ��iFatEntryռ��12λ)
    FatEntryByteOff = iFatEntry * 3 / 2;
    
    ValueTmp = ReadValueToFatBuf(FatEntryByteOff);
    
    return (iFatEntry % 2 == 0 
            ? (ValueTmp & 0x0FFF) 
            : (ValueTmp >> 4 & 0x0FFF));
}

//
// ���õ�ǰiFatEntry��ֵ
VOID WriteFatEntryValue(const UINT16 iFatEntry, UINT16 Value)
{
    UINT16 ValueTmp, FatEntryByteOff;
    
    // iFatEntry��FATBuf�е�ƫ��(ÿ��iFatEntryռ��12λ)
    FatEntryByteOff = iFatEntry * 3 / 2;
    
    ValueTmp = ReadValueToFatBuf(FatEntryByteOff);
    
    // ż��Ҫ����ԭֵ��4λ,����Ҫ����ԭֵ����λ
    if(iFatEntry % 2 == 0)
    {
        Value = Value & 0x0FFF | ValueTmp & 0xF000;
    }
    else
    {
        Value = Value << 4 & 0xFFF0 | ValueTmp & 0x000F;
    }
    
    // ��ֵд��FAT������
    WriteValueToFatBuf(FatEntryByteOff, Value);
}

//
// ��FAT�����ж�ȡֵ
UINT16 ReadValueToFatBuf(const UINT16 FatEntryByteOff)
{
    UINT16 Value = *((PUINT16)&FAT2Buf[FatEntryByteOff]);
    
    if(Value == *((PUINT16)&FAT1Buf[FatEntryByteOff]))
    {
        return Value;
    }
    else
    {
        return (UINT16)-1;
    }
}

//
// ��ֵд��FAT����
VOID WriteValueToFatBuf(const UINT16 FatEntryByteOff, const UINT16 Value)
{
    *((PUINT16)&FAT1Buf[FatEntryByteOff]) = Value;
    *((PUINT16)&FAT2Buf[FatEntryByteOff]) = Value;
}

//
// ��iRootDirEntry��Ӧ�����ݴ��̿�����
UINT16 ReadDataSector(const UINT16 iRootDirEntry, PUCHAR SectorBuf)
{
	if(iRootDirEntry >= FIRSTENTRY 
					&& iRootDirEntry < DATA_SECTOR_NUM + FIRSTENTRY)
	{
		ReadBlock(DATA_START_SECTOR + iRootDirEntry - FIRSTENTRY, 
					SectorBuf);
		return 0;
	}
	else
	{
		return (UINT16)-1;
	}
}

//
// ��iRootDirEntry��Ӧ�����ݴ��̿�д����
UINT16 WriteDataSector(const UINT16 iRootDirEntry, const PUCHAR SectorBuf)
{
	if(iRootDirEntry >= FIRSTENTRY 
					&& iRootDirEntry < DATA_SECTOR_NUM + FIRSTENTRY)
	{
		WriteBlock(DATA_START_SECTOR + iRootDirEntry - FIRSTENTRY, 
					SectorBuf);
		return 0;
	}
	else
	{
		return (UINT16)-1;
	}
}

//
// ���߼���
INT32 ReadBlock(const UINT32 Lba, PUCHAR BlockBuf)
{
    fseek(ImgFp, Lba * SECTOR_SIZE, SEEK_SET);
    return fread(BlockBuf, sizeof(UCHAR), SECTOR_SIZE, ImgFp);
}

//
// д�߼���
INT32 WriteBlock(const UINT32 Lba, const PUCHAR BlockBuf)
{
    fseek(ImgFp, Lba * SECTOR_SIZE, SEEK_SET);
    return fwrite(BlockBuf, sizeof(UCHAR), SECTOR_SIZE, ImgFp);
}