#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "def.h"
#include "_fat12.h"



int main(int argc, char *argv[])
{
	char BlockBuf[SECTOR_SIZE] = {0};
	
    if(argc != 2)
    {
        fprintf(stderr, "usage: TestWriteBlock Image\n");
        exit(EXIT_FAILURE);
    }
	
	InitFat12FileSystem(argv[1]);
	
	BlockBuf[0] = 'A';
	BlockBuf[1] = 'B';
	BlockBuf[510] = 'Y';
	BlockBuf[511] = 'Z';
	WriteBlock(2880-1, BlockBuf);
	
	FreeFat12FileSystem();
	return 0;
}