#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "def.h"
#include "_fat12.h"



int main(int argc, char *argv[])
{
	FILE *NewFp2;
	char *DosFileName2 = "TEST    TXT";
	
    if(argc != 4)
    {
        fprintf(stderr, "usage: TestAddFile Image add_file1 add_file2\n");
        exit(EXIT_FAILURE);
    }
	
	InitFat12FileSystem(argv[1]);
	
	AddFile2Image(argv[2]);
	
    if(NULL == (NewFp2 = fopen(argv[3], "rb")))
    {
        fprintf(stderr, "%s Can't open\n", argv[3]);
        exit(EXIT_FAILURE);
    }
	
	AddFileBase(NewFp2, DosFileName2);
	
	fclose(NewFp2);
	FreeFat12FileSystem();
	return 0;
}