#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "def.h"
#include "_fat12.h"



int main(int argc, char *argv[])
{
	FILE *NewFp1;
	char *FileName1 = "hello.exe";
	
    if(argc != 3)
    {
        fprintf(stderr, "usage: TestCopyFile Image copy_file\n");
        exit(EXIT_FAILURE);
    }
	
	InitFat12FileSystem(argv[1]);
	
    if(NULL == (NewFp1 = fopen(argv[2], "wb")))
    {
        fprintf(stderr, "%s Can't open\n", argv[2]);
        exit(EXIT_FAILURE);
    }
	
	CopyFileBase(NewFp1, FileName1);
	
	fclose(NewFp1);
	FreeFat12FileSystem();
	return 0;
}